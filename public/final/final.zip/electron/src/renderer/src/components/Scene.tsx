export default function Scene() {
  return <div>Scene</div>
}
